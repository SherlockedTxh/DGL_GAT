
from src.Final_value import windows_dir_pre
import collections
import os
def load_train_txt_file():
    PDB_train_Set = set()
    if(os.path.exists(windows_dir_pre+'/PDB_family_train/PDB_family_train.txt')):
        PDB_train_file = open(windows_dir_pre + '/PDB_family_train/PDB_family_train.txt')
        pdb_train_dir = windows_dir_pre + '/PDB_family_train'
        for line in PDB_train_file:
            PDB_ID = line.split()[0]
            PDB_train_Set.add(PDB_ID.lower())
        PDB_train_file.close()
    else:
        print('The file: '+windows_dir_pre+'/PDB_family_train/PDB_family_train.txt'+'is not exist!')
    return PDB_train_Set

def read_dssp(entrylist):
    ID_dict = collections.OrderedDict()
    flag=False
    for line1 in entrylist:
        line = line1.split()
        if line[0]=='#':
            flag=True
            continue
        if flag:
            if line1[13]!='!':
                residuenum = line1[5:11].strip(' ')
                chain = line1[11:13].strip(' ')
                residue_ID=chain+'_'+residuenum
                acc=line1[34:38].strip(' ')
                tco=line1[85:91].strip(' ')
                kappa=line1[91:97].strip(' ')
                alpha=line1[97:103].strip(' ')
                phi=line1[103:109].strip(' ')
                psi=line1[109:115].strip(' ')
                ID_dict[residue_ID]=(acc,tco,kappa,alpha,phi,psi)
    return ID_dict

def read_feature(entrylist):
    ID_dict = collections.OrderedDict()
    for line1 in entrylist:
        line = line1.split()
        ID_dict[line[2]]=(line[1],line[3],line[4],line[5],line[6],line[7],line[8],line[9])
    return ID_dict

def write_str_to_file(string0,path):
    fp=open(path,'w',encoding='utf-8')
    fp.write(string0)
    fp.close()
if __name__ == '__main__':
    print("begin load_train_txt_file()......")
    PDB_train_Set = load_train_txt_file()
    print(len(PDB_train_Set))
    for PDB_ID in PDB_train_Set:
        print(PDB_ID)
        feature_path=windows_dir_pre+'/output/position_and_feature/'+PDB_ID+'.txt'
        dssp_path=windows_dir_pre+'/output/dssp/'+PDB_ID+'.txt'
        output_path=windows_dir_pre+'/output/position_and_feature_with_dssp/'
        if os.path.exists(feature_path) and os.path.exists(dssp_path):
            feature_file = open(feature_path)
            dssp_file=open(dssp_path)
            feature_infile = list(feature_file)
            dssp_infile=list(dssp_file)
            feature_dict=read_feature(feature_infile)
            dssp_dict=read_dssp(dssp_infile)
            output_string=''
            for residue_ID in dssp_dict.keys():
                if residue_ID not in feature_dict.keys():
                    print("Error! "+residue_ID+" is not in feature_dict of "+PDB_ID)
                else:
                    feature=feature_dict[residue_ID]
                    dssp=dssp_dict[residue_ID]
                    output_string+=residue_ID+" "+feature[0]+" "+feature[1]+" "+feature[2]+" "+feature[3]+" "+feature[4]+" "+feature[5]+" "+feature[6]+" "+ \
                                   feature[7] + " " +dssp[0]+" "+dssp[1]+" "+dssp[2]+" "\
                                   +dssp[3]+" "+dssp[4]+" "+dssp[5]+"\n"


            write_str_to_file(output_string,output_path + PDB_ID+'.txt' )
            feature_file.close()
            dssp_file.close()
        else:
            print("Error! "+"No file of "+PDB_ID)